#ifndef CENTER_H
#define CENTER_H

#include <QPoint>

extern int min_x;
extern int min_y;

QPoint Centering();

#endif // CENTER_H
